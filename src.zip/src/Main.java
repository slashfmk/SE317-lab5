public class Main {

    public static void main(String[] args) {

        // Data
        Temperature temp1 = new Temperature(30, 12, 67, Trend.STABLE);
        Temperature temp2 = new Temperature(40, 22, 11, Trend.STABLE);
        Humidity humidity1 = new Humidity(20, 35, 3, Trend.STABLE);
        Humidity humidity2 = new Humidity(30, 5, 1, Trend.STABLE);

        Device device = new Device(temp1, humidity1);

        System.out.println("Before\n");
        device.displayInfo();
        System.out.println("---------------------------------\n");

        System.out.println("After\n");
        device.setTemperature(temp2);
        device.setHumidity(humidity2);

        device.displayInfo();

    }
}
