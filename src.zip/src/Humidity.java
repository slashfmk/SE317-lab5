public class Humidity {

    private int humidity;
    private int max;
    private int min;
    private Trend trend;

    public Humidity(int humidity, int max, int min, Trend trend) {
        this.humidity = humidity;
        this.max = max;
        this.min = min;
        this.trend = trend;
    }

    public Humidity() {
    }

    public int getHumidity() {
        return humidity;
    }

    public void setHumidity(int humidity) {
        this.humidity = humidity;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public Trend getTrend() {
        return trend;
    }

    public void setTrend(Trend trend) {
        this.trend = trend;
    }
}
