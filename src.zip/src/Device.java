public class Device {

    private Temperature[] temperature;
    private Humidity[] humidity;
    private Trend tempTrend;
    private Trend humidTrend;

    public Device(Temperature temperature, Humidity humidity) {
        this.temperature = new Temperature[2];
        this.humidity = new Humidity[2];

        this.temperature[0] = null;
        this.humidity[0] = null;

        this.temperature[1] = temperature;
        this.humidity[1] = humidity;
    }

    public Device() {
    }

    public Temperature getCurrentTemperature() {
        return this.temperature[1];
    }

    public Temperature getPreviousTemperature() {
        return this.temperature[0];
    }

    public void setTemperature(Temperature temperature) {
        if (temperature.getTemp() >= 0 && temperature.getTemp() <= 125) {
            if (this.temperature[0] == null) {
                this.temperature[0] = temperature;
            } else { // if there is a previous one we just put the current
                this.temperature[1] = temperature;
            }
            this.updateTempTrend();
        } else {
            System.out.println("Invalid value [0 - 125]");
        }
    }

    // Humidity
    public Humidity getCurrentHumidity() {
        return this.humidity[1];
    }

    public Humidity getPreviousHumidity() {
        return this.humidity[0];
    }

    public void setHumidity(Humidity humidity) {
        if (humidity.getHumidity() >= 0 && humidity.getHumidity() <= 100) {
            if (this.humidity[0] == null) {
                this.humidity[0] = humidity;
            } else { // if there is a previous one we just put the current
                this.humidity[1] = humidity;
            }

            this.updateHumidityTrend();

        } else {
            // Exception
            System.out.println("Invalid value [0% - 100%]");
        }
    }


    public Trend getTempTrend() {
        return tempTrend;
    }

    public void setTempTrend(Trend tempTrend) {
        this.tempTrend = tempTrend;
    }

    public Trend getHumidTrend() {
        return humidTrend;
    }

    public void setHumidTrend(Trend humidTrend) {
        this.humidTrend = humidTrend;
    }


    public void updateHumidityTrend() {

        this.humidTrend = Trend.STABLE;

        if (this.humidity[0] != null && this.humidity[0].getHumidity() > this.humidity[1].getHumidity()) {
            this.humidTrend = Trend.DOWN;
        } else {
            this.humidTrend = Trend.UP;
        }

    }


    public void updateTempTrend() {

        this.tempTrend = Trend.STABLE;

        if (this.temperature[0] != null && this.temperature[0].getTemp() > this.temperature[1].getTemp()) {
            this.tempTrend = Trend.DOWN;
        } else {
            this.tempTrend = Trend.UP;
        }

    }

    public void displayInfo() {
        System.out.println("Temperature");
        System.out.println("********");
        System.out.println("Current relative temperature: " + this.temperature[1].getTemp() + "F");
        System.out.println("Max relative temperature: " + this.temperature[1].getMax());
        System.out.println("Min relative temperature: " + this.temperature[1].getMin());

        System.out.println("Temperature trend: " + this.getTempTrend());

        System.out.println("");

        System.out.println("Humidity");
        System.out.println("********");
        System.out.println("Current relative humidity: " + this.humidity[1].getHumidity() + "%");
        System.out.println("Max relative humidity: " + this.humidity[1].getMax());
        System.out.println("Min relative humidity: " + this.humidity[1].getMin());

        System.out.println("Humidity trend: " + this.getHumidTrend());
    }


}
