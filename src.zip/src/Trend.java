public enum Trend {

    UP,
    DOWN,
    STABLE

}
