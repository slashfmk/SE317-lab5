public enum HumidityStatus {
    HI,
    OK,
    LOW
}
